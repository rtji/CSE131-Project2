#!/bin/sh
python test-all.py
